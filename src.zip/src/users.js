const users = [
  {
    username: "bilal123_",
    firstName: "Muhammad",
    lastName: "Bilal",
    school: "University of California, Berkeley",
    email: "bilal123@gmail.com",
    profilePicture: "https://picsum.photos/200/300",
  },
  {
    username: "rafay456",
    firstName: "Rafay",
    lastName: "Khalil",
    school: "Stanford University",
    email: "rafay456@yahoo.com",
    profilePicture: "https://picsum.photos/200/300",
  },
  {
    username: "saria789",
    firstName: "Saria",
    lastName: "Manzar",
    school: "Massachusetts Institute of Technology",
    email: "saria789@hotmail.com",
    profilePicture: "https://picsum.photos/200/300",
  },
  {
    username: "ahsan@234",
    firstName: "Muhammad",
    lastName: "Ahsan",
    school: "Harvard University",
    email: "ahsan234@gmail.com",
    profilePicture: "https://picsum.photos/200/300",
  },
  {
    username: "zav567",
    firstName: "Zaviar",
    lastName: "Khan",
    school: "California Institute of Technology",
    email: "zav567@yahoo.com",
    profilePicture: "https://picsum.photos/200/300",
  },
];

export default users;
