import React from "react";
import User from "./User";
import users from "../users";

function UserList() {
  return (
    <div className="user-list">
      {users.map((user) => (
        <User key={user.username} user={user} />
      ))}
    </div>
  );
}

export default UserList;
