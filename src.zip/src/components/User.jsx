import React from "react";

function User({ user }) {
  const { username, firstName, lastName, school, email, profilePicture } = user;
  const classLevel = user.username.length % 2 === 0 ? "Sophomore" : "Freshmen";
  return (
    <div className="user-profile">
      <img src={profilePicture} alt="profile" />
      <div className="user-info">
        <h2>
          {firstName} {lastName}
        </h2>
        <p>Username: {username}</p>
        <p>School: {school}</p>
        <p>Email: {email}</p>
        <p>
          Class Level:{" "}
          <span
            style={{ color: classLevel === "Freshmen" ? "green" : "black" }}
          >
            {classLevel}
          </span>
        </p>
      </div>
    </div>
  );
}

export default User;
